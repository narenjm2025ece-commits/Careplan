package com.careplan.service;

import com.careplan.entity.Medicine;
import com.careplan.entity.Patient;
import com.careplan.exception.ResourceNotFoundException;
import com.careplan.repository.MedicineRepository;
import com.careplan.repository.PatientRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MedicineService {

    private final MedicineRepository medicineRepository;
    private final PatientRepository patientRepository;

    public MedicineService(MedicineRepository medicineRepository, PatientRepository patientRepository) {
        this.medicineRepository = medicineRepository;
        this.patientRepository = patientRepository;
    }

    public Medicine create(Long patientId, Medicine input) {
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found: " + patientId));

        input.setId(null);
        input.setPatient(patient);
        return medicineRepository.save(input);
    }

    public List<Medicine> getByPatient(Long patientId) {
        if (!patientRepository.existsById(patientId)) {
            throw new ResourceNotFoundException("Patient not found: " + patientId);
        }
        return medicineRepository.findByPatientId(patientId);
    }

    public Medicine getById(Long id) {
        return medicineRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Medicine not found: " + id));
    }

    public void delete(Long id) {
        medicineRepository.delete(getById(id));
    }
}
