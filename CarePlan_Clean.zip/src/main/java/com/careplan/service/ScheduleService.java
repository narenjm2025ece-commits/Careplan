package com.careplan.service;

import com.careplan.entity.Frequency;
import com.careplan.entity.Medicine;
import com.careplan.entity.Schedule;
import com.careplan.exception.BusinessRuleException;
import com.careplan.exception.ResourceNotFoundException;
import com.careplan.repository.MedicineRepository;
import com.careplan.repository.ScheduleRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScheduleService {

    private final ScheduleRepository scheduleRepository;
    private final MedicineRepository medicineRepository;

    public ScheduleService(ScheduleRepository scheduleRepository, MedicineRepository medicineRepository) {
        this.scheduleRepository = scheduleRepository;
        this.medicineRepository = medicineRepository;
    }

    public Schedule create(Long medicineId, Schedule input) {
        Medicine medicine = medicineRepository.findById(medicineId)
                .orElseThrow(() -> new ResourceNotFoundException("Medicine not found: " + medicineId));

        if (input.getEndDate() != null && input.getEndDate().isBefore(input.getStartDate())) {
            throw new BusinessRuleException("End date cannot be before start date");
        }

        if (input.getFrequency() == null) {
            input.setFrequency(Frequency.DAILY);
        }

        input.setId(null);
        input.setMedicine(medicine);
        return scheduleRepository.save(input);
    }

    public List<Schedule> getByMedicine(Long medicineId) {
        if (!medicineRepository.existsById(medicineId)) {
            throw new ResourceNotFoundException("Medicine not found: " + medicineId);
        }
        return scheduleRepository.findByMedicineId(medicineId);
    }
}
