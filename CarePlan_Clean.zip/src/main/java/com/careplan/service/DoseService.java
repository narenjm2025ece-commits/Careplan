package com.careplan.service;

import com.careplan.entity.*;
import com.careplan.exception.BusinessRuleException;
import com.careplan.exception.ResourceNotFoundException;
import com.careplan.repository.DoseLogRepository;
import com.careplan.repository.PatientRepository;
import com.careplan.repository.ScheduleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class DoseService {

    private final DoseLogRepository doseLogRepository;
    private final ScheduleRepository scheduleRepository;
    private final PatientRepository patientRepository;

    public DoseService(DoseLogRepository doseLogRepository,
                       ScheduleRepository scheduleRepository,
                       PatientRepository patientRepository) {
        this.doseLogRepository = doseLogRepository;
        this.scheduleRepository = scheduleRepository;
        this.patientRepository = patientRepository;
    }

    @Transactional
    public List<DoseLog> generateToday(Long patientId) {
        if (!patientRepository.existsById(patientId)) {
            throw new ResourceNotFoundException("Patient not found: " + patientId);
        }

        LocalDate today = LocalDate.now();
        List<DoseLog> result = new ArrayList<>();

        for (Schedule schedule : scheduleRepository.findByMedicinePatientId(patientId)) {
            if (!isActiveToday(schedule, today)) {
                continue;
            }

            DoseLog log = doseLogRepository
                    .findByScheduleIdAndDoseDateAndScheduledTime(
                            schedule.getId(), today, schedule.getDoseTime())
                    .orElseGet(() -> {
                        DoseLog newLog = new DoseLog();
                        newLog.setSchedule(schedule);
                        newLog.setDoseDate(today);
                        newLog.setScheduledTime(schedule.getDoseTime());
                        newLog.setStatus(DoseStatus.PENDING);
                        return doseLogRepository.save(newLog);
                    });

            result.add(log);
        }

        return result;
    }

    private boolean isActiveToday(Schedule schedule, LocalDate today) {
        if (today.isBefore(schedule.getStartDate())) {
            return false;
        }

        if (schedule.getEndDate() != null && today.isAfter(schedule.getEndDate())) {
            return false;
        }

        if (schedule.getFrequency() == Frequency.WEEKLY) {
            return today.getDayOfWeek() == schedule.getStartDate().getDayOfWeek();
        }

        return true;
    }

    @Transactional
    public DoseLog markTaken(Long logId, String note) {
        DoseLog log = getLog(logId);

        if (log.getStatus() == DoseStatus.TAKEN) {
            throw new BusinessRuleException("This dose is already marked as TAKEN");
        }

        if (log.getStatus() == DoseStatus.MISSED) {
            throw new BusinessRuleException("A MISSED dose cannot be marked as TAKEN");
        }

        log.setStatus(DoseStatus.TAKEN);
        log.setActionTime(LocalDateTime.now());
        log.setNote(note);
        return doseLogRepository.save(log);
    }

    @Transactional
    public DoseLog markMissed(Long logId, String note) {
        DoseLog log = getLog(logId);

        if (log.getStatus() == DoseStatus.TAKEN) {
            throw new BusinessRuleException("A TAKEN dose cannot be marked as MISSED");
        }

        if (log.getStatus() == DoseStatus.MISSED) {
            throw new BusinessRuleException("This dose is already marked as MISSED");
        }

        log.setStatus(DoseStatus.MISSED);
        log.setActionTime(LocalDateTime.now());
        log.setNote(note);
        return doseLogRepository.save(log);
    }

    public List<DoseLog> missedHistory(Long patientId, LocalDate from, LocalDate to) {
        if (!patientRepository.existsById(patientId)) {
            throw new ResourceNotFoundException("Patient not found: " + patientId);
        }

        if (from.isAfter(to)) {
            throw new BusinessRuleException("From date cannot be after to date");
        }

        return doseLogRepository
                .findByScheduleMedicinePatientIdAndDoseDateBetweenAndStatus(
                        patientId, from, to, DoseStatus.MISSED);
    }

    @Transactional
    public List<DoseLog> overdueToday(Long patientId) {
        List<DoseLog> today = generateToday(patientId);
        LocalTime cutoff = LocalTime.now().minusHours(1);

        return today.stream()
                .filter(log -> log.getStatus() == DoseStatus.PENDING)
                .filter(log -> log.getScheduledTime().isBefore(cutoff))
                .toList();
    }

    private DoseLog getLog(Long id) {
        return doseLogRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Dose log not found: " + id));
    }
}
