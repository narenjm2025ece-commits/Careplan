package com.careplan.service;

import com.careplan.entity.Patient;
import com.careplan.exception.ResourceNotFoundException;
import com.careplan.repository.PatientRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    private final PatientRepository repository;

    public PatientService(PatientRepository repository) {
        this.repository = repository;
    }

    public Patient create(Patient patient) {
        return repository.save(patient);
    }

    public List<Patient> getAll() {
        return repository.findAll();
    }

    public Patient getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found: " + id));
    }

    public Patient update(Long id, Patient input) {
        Patient patient = getById(id);
        patient.setName(input.getName());
        patient.setDateOfBirth(input.getDateOfBirth());
        patient.setCaregiverName(input.getCaregiverName());
        patient.setCaregiverPhone(input.getCaregiverPhone());
        return repository.save(patient);
    }

    public void delete(Long id) {
        repository.delete(getById(id));
    }
}
