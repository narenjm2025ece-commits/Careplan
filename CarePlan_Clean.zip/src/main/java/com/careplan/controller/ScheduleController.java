package com.careplan.controller;

import com.careplan.entity.Schedule;
import com.careplan.service.ScheduleService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ScheduleController {

    private final ScheduleService service;

    public ScheduleController(ScheduleService service) {
        this.service = service;
    }

    @PostMapping("/api/medicines/{medicineId}/schedules")
    @ResponseStatus(HttpStatus.CREATED)
    public Schedule create(@PathVariable Long medicineId, @Valid @RequestBody Schedule schedule) {
        return service.create(medicineId, schedule);
    }

    @GetMapping("/api/medicines/{medicineId}/schedules")
    public List<Schedule> getByMedicine(@PathVariable Long medicineId) {
        return service.getByMedicine(medicineId);
    }
}
