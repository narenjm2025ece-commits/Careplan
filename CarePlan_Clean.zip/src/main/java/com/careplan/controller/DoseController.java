package com.careplan.controller;

import com.careplan.entity.DoseLog;
import com.careplan.service.DoseService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
public class DoseController {

    private final DoseService service;

    public DoseController(DoseService service) {
        this.service = service;
    }

    @GetMapping("/api/patients/{patientId}/doses/today")
    public List<DoseLog> today(@PathVariable Long patientId) {
        return service.generateToday(patientId);
    }

    @PutMapping("/api/doses/{doseLogId}/taken")
    public DoseLog taken(@PathVariable Long doseLogId,
                          @RequestParam(required = false) String note) {
        return service.markTaken(doseLogId, note);
    }

    @PutMapping("/api/doses/{doseLogId}/missed")
    public DoseLog missed(@PathVariable Long doseLogId,
                           @RequestParam(required = false) String note) {
        return service.markMissed(doseLogId, note);
    }

    @GetMapping("/api/patients/{patientId}/doses/missed")
    public List<DoseLog> missedHistory(
            @PathVariable Long patientId,
            @RequestParam LocalDate from,
            @RequestParam LocalDate to) {
        return service.missedHistory(patientId, from, to);
    }

    @GetMapping("/api/patients/{patientId}/doses/overdue")
    public List<DoseLog> overdue(@PathVariable Long patientId) {
        return service.overdueToday(patientId);
    }
}
