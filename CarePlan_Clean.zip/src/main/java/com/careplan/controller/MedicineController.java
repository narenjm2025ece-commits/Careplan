package com.careplan.controller;

import com.careplan.entity.Medicine;
import com.careplan.service.MedicineService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MedicineController {

    private final MedicineService service;

    public MedicineController(MedicineService service) {
        this.service = service;
    }

    @PostMapping("/api/patients/{patientId}/medicines")
    @ResponseStatus(HttpStatus.CREATED)
    public Medicine create(@PathVariable Long patientId, @Valid @RequestBody Medicine medicine) {
        return service.create(patientId, medicine);
    }

    @GetMapping("/api/patients/{patientId}/medicines")
    public List<Medicine> getByPatient(@PathVariable Long patientId) {
        return service.getByPatient(patientId);
    }

    @GetMapping("/api/medicines/{id}")
    public Medicine get(@PathVariable Long id) {
        return service.getById(id);
    }

    @DeleteMapping("/api/medicines/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
