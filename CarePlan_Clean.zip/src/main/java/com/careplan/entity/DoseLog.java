package com.careplan.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Table(
    name = "dose_logs",
    uniqueConstraints = @UniqueConstraint(
        name = "uk_schedule_date_time",
        columnNames = {"schedule_id", "dose_date", "scheduled_time"}
    )
)
public class DoseLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull
    @Column(name = "dose_date", nullable = false)
    private LocalDate doseDate;

    @NotNull
    @Column(name = "scheduled_time", nullable = false)
    private LocalTime scheduledTime;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DoseStatus status = DoseStatus.PENDING;

    private LocalDateTime actionTime;

    private String note;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "schedule_id", nullable = false)
    @JsonIgnore
    private Schedule schedule;

    public DoseLog() {}

    public Long getId() { return id; }
    public LocalDate getDoseDate() { return doseDate; }
    public LocalTime getScheduledTime() { return scheduledTime; }
    public DoseStatus getStatus() { return status; }
    public LocalDateTime getActionTime() { return actionTime; }
    public String getNote() { return note; }
    public Schedule getSchedule() { return schedule; }

    public void setId(Long id) { this.id = id; }
    public void setDoseDate(LocalDate doseDate) { this.doseDate = doseDate; }
    public void setScheduledTime(LocalTime scheduledTime) { this.scheduledTime = scheduledTime; }
    public void setStatus(DoseStatus status) { this.status = status; }
    public void setActionTime(LocalDateTime actionTime) { this.actionTime = actionTime; }
    public void setNote(String note) { this.note = note; }
    public void setSchedule(Schedule schedule) { this.schedule = schedule; }
}
