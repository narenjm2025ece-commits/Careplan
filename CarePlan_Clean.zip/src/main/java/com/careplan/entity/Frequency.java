package com.careplan.entity;

public enum Frequency {
    DAILY,
    WEEKLY
}
