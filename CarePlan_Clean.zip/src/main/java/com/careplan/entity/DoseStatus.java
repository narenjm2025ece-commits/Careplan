package com.careplan.entity;

public enum DoseStatus {
    PENDING,
    TAKEN,
    MISSED
}
