package com.careplan.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "medicines")
public class Medicine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Medicine name is required")
    private String name;

    @NotBlank(message = "Dosage is required")
    private String dosage;

    @Positive(message = "Quantity must be greater than zero")
    private Double quantity;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    @JsonIgnore
    private Patient patient;

    @JsonIgnore
    @OneToMany(mappedBy = "medicine", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Schedule> schedules = new ArrayList<>();

    public Medicine() {}

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getDosage() { return dosage; }
    public Double getQuantity() { return quantity; }
    public Patient getPatient() { return patient; }
    public List<Schedule> getSchedules() { return schedules; }

    public void setId(Long id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setDosage(String dosage) { this.dosage = dosage; }
    public void setQuantity(Double quantity) { this.quantity = quantity; }
    public void setPatient(Patient patient) { this.patient = patient; }
    public void setSchedules(List<Schedule> schedules) { this.schedules = schedules; }
}
