package com.careplan.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "schedules")
public class Schedule {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "Start date is required")
    private LocalDate startDate;

    private LocalDate endDate;

    @NotNull(message = "Dose time is required")
    private LocalTime doseTime;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Frequency frequency = Frequency.DAILY;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "medicine_id", nullable = false)
    @JsonIgnore
    private Medicine medicine;

    @JsonIgnore
    @OneToMany(mappedBy = "schedule", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DoseLog> doseLogs = new ArrayList<>();

    public Schedule() {}

    public Long getId() { return id; }
    public LocalDate getStartDate() { return startDate; }
    public LocalDate getEndDate() { return endDate; }
    public LocalTime getDoseTime() { return doseTime; }
    public Frequency getFrequency() { return frequency; }
    public Medicine getMedicine() { return medicine; }
    public List<DoseLog> getDoseLogs() { return doseLogs; }

    public void setId(Long id) { this.id = id; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public void setDoseTime(LocalTime doseTime) { this.doseTime = doseTime; }
    public void setFrequency(Frequency frequency) { this.frequency = frequency; }
    public void setMedicine(Medicine medicine) { this.medicine = medicine; }
    public void setDoseLogs(List<DoseLog> doseLogs) { this.doseLogs = doseLogs; }
}
