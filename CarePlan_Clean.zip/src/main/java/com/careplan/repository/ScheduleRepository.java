package com.careplan.repository;

import com.careplan.entity.Schedule;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ScheduleRepository extends JpaRepository<Schedule, Long> {
    List<Schedule> findByMedicineId(Long medicineId);
    List<Schedule> findByMedicinePatientId(Long patientId);
}
