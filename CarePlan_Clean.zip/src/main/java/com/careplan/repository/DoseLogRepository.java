package com.careplan.repository;

import com.careplan.entity.DoseLog;
import com.careplan.entity.DoseStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

public interface DoseLogRepository extends JpaRepository<DoseLog, Long> {

    boolean existsByScheduleIdAndDoseDateAndScheduledTime(
            Long scheduleId, LocalDate doseDate, LocalTime scheduledTime);

    Optional<DoseLog> findByScheduleIdAndDoseDateAndScheduledTime(
            Long scheduleId, LocalDate doseDate, LocalTime scheduledTime);

    List<DoseLog> findByScheduleMedicinePatientIdAndDoseDateBetweenAndStatus(
            Long patientId, LocalDate from, LocalDate to, DoseStatus status);

    List<DoseLog> findByScheduleMedicinePatientIdAndDoseDateAndStatus(
            Long patientId, LocalDate date, DoseStatus status);
}
